import socket
import threading

HOST = "0.0.0.0"
PORT = 6000

clients = []
lock = threading.Lock()


def broadcast(message, sender=None):
    with lock:
        targets = list(clients)
    for c in targets:
        if c is not sender:
            try:
                c.sendall(message)
            except OSError:
                pass


def handle(conn, addr):
    name = addr[0] + ":" + str(addr[1])
    print(name, "joined")
    broadcast((name + " joined the chat\n").encode(), conn)
    try:
        while True:
            data = conn.recv(1024)
            if not data:
                break
            text = data.decode().strip()
            print(name, ":", text)
            broadcast((name + ": " + text + "\n").encode(), conn)
    except OSError:
        pass
    with lock:
        if conn in clients:
            clients.remove(conn)
    conn.close()
    print(name, "left")
    broadcast((name + " left the chat\n").encode())


server = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
server.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, 1)
server.bind((HOST, PORT))
server.listen(10)
print("Chat server running on port", PORT)

while True:
    conn, addr = server.accept()
    with lock:
        clients.append(conn)
    threading.Thread(target=handle, args=(conn, addr), daemon=True).start()
