import socket
import threading

HOST = "127.0.0.1"
PORT = 6000


def receive(sock):
    while True:
        try:
            data = sock.recv(1024)
        except OSError:
            break
        if not data:
            print("Disconnected from server")
            break
        print(data.decode(), end="")


client = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
client.connect((HOST, PORT))
print("Connected. Type messages and press Enter. Type quit to exit.")

threading.Thread(target=receive, args=(client,), daemon=True).start()

while True:
    msg = input()
    if msg.lower() == "quit":
        break
    client.sendall(msg.encode())

client.close()
