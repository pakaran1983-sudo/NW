import socket
import re

HOST = "0.0.0.0"
PORT = 5001

ABBR = {
    "tbh": "to be honest",
    "ig": "I guess",
    "tbf": "to be fair",
    "atm": "at the moment",
    "irl": "in real life",
    "lol": "laughing out loud",
    "asap": "as soon as possible",
    "omg": "oh my god",
    "ttyl": "talk to you later",
    "idk": "I don't know",
    "nvm": "never mind",
    "idc": "I don't care",
}


def translate(text):
    def swap(match):
        word = match.group(0)
        return ABBR.get(word.lower(), word)

    return re.sub(r"[A-Za-z]+", swap, text)


server = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
server.bind((HOST, PORT))
print("UDP translator server running on port", PORT)

while True:
    data, addr = server.recvfrom(4096)
    sentence = data.decode()
    print("Received from", addr, ":", sentence)
    result = translate(sentence)
    print("Sent back:", result)
    server.sendto(result.encode(), addr)
