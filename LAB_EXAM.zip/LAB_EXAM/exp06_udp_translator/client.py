import socket

HOST = "127.0.0.1"
PORT = 5001

client = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
client.settimeout(5)

sentence = input("Enter sentence: ")
client.sendto(sentence.encode(), (HOST, PORT))

try:
    data, addr = client.recvfrom(4096)
    print("Translated:", data.decode())
except socket.timeout:
    print("No reply from server (is server.py running?)")

client.close()
