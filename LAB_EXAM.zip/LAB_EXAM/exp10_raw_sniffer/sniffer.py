import socket
import struct
import os

if os.name == "nt":
    host = socket.gethostbyname(socket.gethostname())
    sniffer = socket.socket(socket.AF_INET, socket.SOCK_RAW, socket.IPPROTO_IP)
    sniffer.bind((host, 0))
    sniffer.setsockopt(socket.IPPROTO_IP, socket.IP_HDRINCL, 1)
    sniffer.ioctl(socket.SIO_RCVALL, socket.RCVALL_ON)
    HAS_ETHERNET = False
else:
    sniffer = socket.socket(socket.AF_PACKET, socket.SOCK_RAW, socket.ntohs(3))
    HAS_ETHERNET = True


def mac(raw):
    return ":".join("%02x" % b for b in raw)


def parse_ip(data):
    ihl = (data[0] & 15) * 4
    ttl, proto, src, dst = struct.unpack("!8xBB2x4s4s", data[:20])
    return ihl, ttl, proto, socket.inet_ntoa(src), socket.inet_ntoa(dst)


count = 0
print("Sniffing... press Ctrl+C to stop")

try:
    while True:
        packet, _ = sniffer.recvfrom(65535)
        data = packet

        if HAS_ETHERNET:
            dst_mac, src_mac, eth_type = struct.unpack("!6s6sH", packet[:14])
            if eth_type != 0x0800:
                continue
            print("\nPacket", count + 1)
            print("Ethernet: src", mac(src_mac), "dst", mac(dst_mac))
            data = packet[14:]
        else:
            print("\nPacket", count + 1)

        count += 1
        ihl, ttl, proto, src_ip, dst_ip = parse_ip(data)
        print("IPv4: src", src_ip, "dst", dst_ip, "ttl", ttl, "protocol", proto)
        payload = data[ihl:]

        if proto == 6 and len(payload) >= 14:
            sport, dport, seq, ack, off_flags = struct.unpack("!HHLLH", payload[:14])
            flags = off_flags & 0x3F
            names = []
            for bit, name in ((0x20, "URG"), (0x10, "ACK"), (0x08, "PSH"), (0x04, "RST"), (0x02, "SYN"), (0x01, "FIN")):
                if flags & bit:
                    names.append(name)
            print("TCP: port", sport, "->", dport, "seq", seq, "ack", ack, "flags", ",".join(names))
        elif proto == 17 and len(payload) >= 8:
            sport, dport, length = struct.unpack("!HHH", payload[:6])
            print("UDP: port", sport, "->", dport, "length", length)
        elif proto == 1 and len(payload) >= 2:
            print("ICMP: type", payload[0], "code", payload[1])
        else:
            print("Other protocol number", proto)
except KeyboardInterrupt:
    print("\nStopped. Packets captured:", count)
    if os.name == "nt":
        sniffer.ioctl(socket.SIO_RCVALL, socket.RCVALL_OFF)
