import socket
import threading
import os

HOST = "0.0.0.0"
PORT = 8000


def handle(conn, addr):
    filename = os.path.basename(conn.recv(1024).decode().strip())
    print("Request from", addr, "for", filename)
    header = "Server PID: " + str(os.getpid()) + "\n"
    if os.path.isfile(filename):
        with open(filename, "rb") as f:
            content = f.read()
        conn.sendall(header.encode() + b"STATUS: FILE FOUND\n--- file contents ---\n" + content)
    else:
        conn.sendall(header.encode() + b"STATUS: FILE NOT FOUND\n")
    conn.close()


server = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
server.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, 1)
server.bind((HOST, PORT))
server.listen(10)
print("File server running on port", PORT, "PID", os.getpid())

while True:
    conn, addr = server.accept()
    threading.Thread(target=handle, args=(conn, addr), daemon=True).start()
