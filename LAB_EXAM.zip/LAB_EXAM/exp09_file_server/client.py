import socket

HOST = "127.0.0.1"
PORT = 8000

filename = input("Enter file name to request: ")

client = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
client.connect((HOST, PORT))
client.sendall(filename.encode())

chunks = []
while True:
    data = client.recv(4096)
    if not data:
        break
    chunks.append(data)

print(b"".join(chunks).decode(errors="replace"))
client.close()
