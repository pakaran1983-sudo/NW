import socket

HOST = "127.0.0.1"
PORT = 7000

client = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
client.settimeout(5)
client.sendto(b"TIME", (HOST, PORT))

try:
    data, addr = client.recvfrom(1024)
    print("Server time:", data.decode())
except socket.timeout:
    print("No reply from server (is server.py running?)")

client.close()
