import socket
import threading
from datetime import datetime

HOST = "0.0.0.0"
PORT = 7000


def reply(sock, addr):
    now = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
    sock.sendto(now.encode(), addr)
    print("Sent time to", addr)


server = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
server.bind((HOST, PORT))
print("UDP time server running on port", PORT)

while True:
    data, addr = server.recvfrom(1024)
    if data.decode().strip().upper() == "TIME":
        threading.Thread(target=reply, args=(server, addr), daemon=True).start()
