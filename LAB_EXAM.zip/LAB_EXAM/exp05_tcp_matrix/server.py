import socket
import json

HOST = "0.0.0.0"
PORT = 5000


def matrix_type(m):
    n = len(m)
    upper = all(m[i][j] == 0 for i in range(n) for j in range(i))
    lower = all(m[i][j] == 0 for i in range(n) for j in range(i + 1, n))
    if upper and lower:
        return "Diagonal matrix"
    if upper:
        return "Upper triangular matrix"
    if lower:
        return "Lower triangular matrix"
    return "Not triangular or diagonal (full matrix)"


server = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
server.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, 1)
server.bind((HOST, PORT))
server.listen(5)
print("Server listening on port", PORT)

while True:
    conn, addr = server.accept()
    print("Connected:", addr)
    line = conn.makefile("r").readline()
    matrix = json.loads(line)
    print("Received matrix:")
    for row in matrix:
        print(row)
    result = matrix_type(matrix)
    print("Type:", result)
    conn.sendall(result.encode())
    conn.close()
