import socket
import json
import random

HOST = "127.0.0.1"
PORT = 5000

n = int(input("Enter N (order of square matrix): "))
matrix = [[random.randint(1, 50) for _ in range(n)] for _ in range(n)]

print("Choose matrix shape to generate:")
print("1 - Upper triangular")
print("2 - Lower triangular")
print("3 - Diagonal")
print("4 - Full (random, no zeros)")
choice = input("Enter choice: ")

for i in range(n):
    for j in range(n):
        if choice == "1" and i > j:
            matrix[i][j] = 0
        elif choice == "2" and i < j:
            matrix[i][j] = 0
        elif choice == "3" and i != j:
            matrix[i][j] = 0

print("Matrix sent to server:")
for row in matrix:
    print(row)

client = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
client.connect((HOST, PORT))
client.sendall((json.dumps(matrix) + "\n").encode())
reply = client.recv(1024).decode()
print("Server says:", reply)
client.close()
