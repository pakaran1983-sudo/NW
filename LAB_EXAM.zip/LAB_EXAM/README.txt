NETWORKS LAB (PCCSL507) - EXAM KIT
===================================

FOLDER MAP (copy the whole LAB_EXAM folder to the pendrive)
-----------------------------------------------------------
LAB_EXAM/
  README.txt                          <- this file
  exp01_linux_commands/commands.txt   <- Exp 1
  exp02_wireshark_http/steps.txt      <- Exp 2
  exp03_wireshark_smtp/steps.txt      <- Exp 3
  exp04_wireshark_dns/steps.txt       <- Exp 4
  exp05_tcp_matrix/server.py client.py
  exp06_udp_translator/server.py client.py
  exp07_tcp_chat/server.py client.py
  exp08_udp_time/server.py client.py
  exp09_file_server/server.py client.py sample.txt
  exp10_raw_sniffer/sniffer.py
  cisco/                              <- Exp 11 to 17 (Packet Tracer)
    00_topology_cabling_pc_setup.txt  <- READ FIRST (build network, where to type)
    01_BASE_interface_config_IPv4.txt <- paste first for Exp 11-16
    11_router_commands.txt
    12_static_routing.txt
    13_ripv2.txt
    14_ospf.txt
    15_acl_standard_host_b.txt
    16_acl_extended_hackathon.txt
    17_ripng_ipv6.txt
    18_exam_tips.txt


HOW TO RUN THE PYTHON PROGRAMS (Exp 5 to 10)
---------------------------------------------
1. Copy the experiment folder from the pendrive to the Desktop (pendrives can be read-only/slow).
2. Open a terminal IN that folder.
     Linux: right click inside folder -> "Open in Terminal"
     Windows: click the address bar of the folder, type  cmd  and press Enter
3. Start the SERVER first, in terminal 1:
     Linux:   python3 server.py
     Windows: python server.py
4. Open a SECOND terminal in the same folder and start the CLIENT:
     python3 client.py
5. Both on the same PC: leave HOST = "127.0.0.1" (already set).
   Server and client on DIFFERENT PCs: open client.py, change HOST = "127.0.0.1"
   to the server PC's IP (find it with  ip a  on Linux or  ipconfig  on Windows).
6. Stop a program with Ctrl+C.

If "Address already in use": wait 30 seconds or change PORT in BOTH files.
If "python3 not found" on Windows, use  python  ;  on Linux use  python3 .
Exp 10 (sniffer) needs admin rights: Linux  sudo python3 sniffer.py ; Windows: open cmd as Administrator.
